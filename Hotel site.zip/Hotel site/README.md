# Hotel Template with Bootstrap

## Hotel website template with Bootstrap - fully responsive

![](images/screen-mockup.jpg)
